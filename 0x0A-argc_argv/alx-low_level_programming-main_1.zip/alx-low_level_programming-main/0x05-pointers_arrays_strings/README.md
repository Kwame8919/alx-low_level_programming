# Pointers and Arrays Strings
