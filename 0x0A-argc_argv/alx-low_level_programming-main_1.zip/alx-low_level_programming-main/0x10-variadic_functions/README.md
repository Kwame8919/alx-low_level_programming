# Variadic Functions
