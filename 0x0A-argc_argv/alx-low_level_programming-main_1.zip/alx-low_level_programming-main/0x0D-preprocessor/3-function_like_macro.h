#ifndef FILE_ABS
#define FILE_ABS

#define ABS(X) ((X) < 0 ? -1 * (X) : (X))


#endif

