#ifndef FILE_SUM
#define FILE_SUM

#define SUM(X, Y)  ((X) + (Y))


#endif

