# Structures typedef
