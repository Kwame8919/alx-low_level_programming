#include "main.h"

/**
 * _isdigit - check the code for Holberton School students.
 *
 * @c: is an integer param
 *
 * Return: Always 0.
 */


int _isdigit(int c)
{

	return (c >= 48 && c <= 57);
}

